﻿#include "Game.h"
#include "Box2DHelper.h"

// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{
	wnd = new RenderWindow(VideoMode(ancho, alto), titulo); // Crea una ventana con las dimensiones y título especificados
	wnd->setVisible(true); // Hace visible la ventana
	fps = 60; // Establece el límite de cuadros por segundo (FPS)
	wnd->setFramerateLimit(fps); // Aplica el límite de FPS a la ventana
	frameTime = 1.0f / fps; // Calcula el tiempo por cuadro en segundos
	SetZoom(); // Configura el "zoom" o vista de la cámara
	InitPhysics(); // Inicializa la simulación de física
}

void Game::Loop()
{
	while (wnd->isOpen()) // Bucle principal del juego que se ejecuta mientras la ventana esté abierta
	{
		wnd->clear(clearColor); // Limpia la ventana con el color de fondo
		DoEvents(); // Maneja los eventos (input del usuario)
		CheckCollitions(); // Verifica colisiones (a implementar)
		UpdatePhysics(); // Actualiza la simulación de física
		DrawGame(); // Dibuja los elementos del juego
		wnd->display(); // Muestra los cambios en la ventana
	}
}

void Game::UpdatePhysics()
{
	phyWorld->Step(frameTime, 8, 8); // Avanza la simulación de física un paso
	phyWorld->ClearForces(); // Limpia las fuerzas acumuladas
	phyWorld->DebugDraw(); // Dibuja la representación de debug de la simulación
}

void Game::DoEvents()
{
	Event evt;
	while (wnd->pollEvent(evt))
	{
		switch (evt.type)
		{
		case Event::Closed:
			wnd->close();
			break;

		case Event::MouseButtonPressed:
			if (evt.mouseButton.button == Mouse::Left)
			{
				Vector2f pos = wnd->mapPixelToCoords(Vector2i(evt.mouseButton.x, evt.mouseButton.y));
				b2Vec2 mouseWorldPos(pos.x, pos.y);

				// Hacemos una búsqueda AABB alrededor del mouse para detectar cuerpos
				b2AABB aabb;
				b2Vec2 d(0.001f, 0.001f);
				aabb.lowerBound = mouseWorldPos - d;
				aabb.upperBound = mouseWorldPos + d;

				b2Body* selectedBody = nullptr;

				class QueryCallback : public b2QueryCallback
				{
				public:
					b2Vec2 point;
					b2Body* foundBody = nullptr;

					QueryCallback(const b2Vec2& point) : point(point) {}

					bool ReportFixture(b2Fixture* fixture) override
					{
						if (fixture->GetBody()->GetType() == b2_dynamicBody)
						{
							if (fixture->TestPoint(point))
							{
								foundBody = fixture->GetBody();
								return false; // Terminamos la búsqueda
							}
						}
						return true; // Seguimos buscando
					}
				};

				QueryCallback queryCallback(mouseWorldPos);
				phyWorld->QueryAABB(&queryCallback, aabb);

				if (queryCallback.foundBody)
				{
					selectedBody = queryCallback.foundBody;

					// Creamos un mouse joint anclado a un cuerpo estático invisible
					if (!mouseBody)
					{
						b2BodyDef bd;
						mouseBody = phyWorld->CreateBody(&bd); // cuerpo estático vacío
					}

					b2MouseJointDef mjd;
					mjd.bodyA = mouseBody;
					mjd.bodyB = selectedBody;
					mjd.target = mouseWorldPos;
					mjd.maxForce = 1000.0f * selectedBody->GetMass();
					mjd.stiffness = 250.0f;
					mjd.damping = 0.9f;

					mouseJoint = static_cast<b2MouseJoint*>(phyWorld->CreateJoint(&mjd));
					selectedBody->SetAwake(true);
				}
			}
			break;

		case Event::MouseButtonReleased:
			if (evt.mouseButton.button == Mouse::Left)
			{
				if (mouseJoint)
				{
					phyWorld->DestroyJoint(mouseJoint);
					mouseJoint = nullptr;
				}
			}
			break;

		case Event::MouseMoved:
			if (mouseJoint)
			{
				Vector2f pos = wnd->mapPixelToCoords(Vector2i(evt.mouseMove.x, evt.mouseMove.y));
				mouseJoint->SetTarget(b2Vec2(pos.x, pos.y));
			}
			break;
		}
	}
}
void Game::DrawGame()
{
	// Función para dibujar los elementos del juego (a implementar)
}
void Game::CheckCollitions()
{
	// Verificación de colisiones (a implementar)
}
void Game::SetZoom()
{
	View camara;
	camara.setSize(100.0f, 100.0f); // Establece el tamaño de la vista
	camara.setCenter(50.0f, 50.0f); // Centra la vista en un punto del mundo
	wnd->setView(camara); // Aplica la vista a la ventana
}
void Game::InitPhysics()
{
	// Inicializa el mundo de Box2D con una gravedad hacia abajo
	phyWorld = new b2World(b2Vec2(0.0f, 9.8f));

	debugRender = new SFMLRenderer(wnd); // Crea un renderizador de debug para SFML
	debugRender->SetFlags(UINT_MAX); // Configura el renderizador para dibujar todas las formas de debug
	phyWorld->SetDebugDraw(debugRender); // Establece el renderizador de debug para el mundo de Box2D

	// Crea cuerpos estáticos para simular el suelo y las paredes
	// También crea cuerpos dinámicos (como círculos) y los une con resortes al techo para demostrar la simulación física
	groundBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 100, 10);
	groundBody->SetTransform(b2Vec2(50.0f, 100.0f), 0.0f);

	b2Body* leftWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 10, 100);
	leftWallBody->SetTransform(b2Vec2(0.0f, 50.0f), 0.0f);

	b2Body* rightWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 10, 100);
	rightWallBody->SetTransform(b2Vec2(100.0f, 50.0f), 0.0f);

	// Creamos un techo
	b2Body* topWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 100, 10);
	topWallBody->SetTransform(b2Vec2(50.0f, 0.0f), 0.0f);

	// Creamos parte por parte el ragodll
	/*
	Torso = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 5.0f, 10.0f, 1.0f, 1.0f, 0.0f);
	Torso->SetTransform(b2Vec2(30.0f, 20.0f), 0.0f);

	BrazoD = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 2.0f, 8.0f, 1.0f, 1.0, 0.0f);
	BrazoI = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 2.0f, 8.0f, 1.0f, 1.0, 0.0f);
	BrazoD->SetTransform(b2Vec2(Torso->GetPosition().x + 5.0f, Torso->GetPosition().y), -0.3f);
	BrazoI->SetTransform(b2Vec2(Torso->GetPosition().x - 5.0f, Torso->GetPosition().y), 0.3f);

	PiernaD = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 2.0f, 8.0f, 1.0f, 1.0, 0.0f);
	PiernaI = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 2.0f, 8.0f, 1.0f, 1.0, 0.0f);
	PiernaD->SetTransform(b2Vec2(Torso->GetPosition().x + 1.9f, Torso->GetPosition().y + 9.0f), -0.1f);
	PiernaI->SetTransform(b2Vec2(Torso->GetPosition().x - 1.9f, Torso->GetPosition().y + 9.0f), 0.1f);
	*/
	Head = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 5.0f, 5.0f, 1.0f, 0.4f, 0.8f);
	Head->SetTransform(b2Vec2(30.0f, 12.0f), 0.0f);


	// Joints al torso
	// 
	// Hay pruebas con distanceJoint pero Revolute te pide impedir ciertos rangos de angulos de movimiento lo cual lo hace mucho mejor
	
	//Cabeza	
	Box2DHelper::CreateDistanceJoint(phyWorld, leftWallBody, leftWallBody->GetWorldCenter()+b2Vec2(0,15.0f), Head, Head->GetWorldCenter(), 15.0f, 0.3f, 1.0f);
	//Box2DHelper::CreateRevoluteJoint(phyWorld, Torso, Torso->GetWorldCenter(), Head, 0, 0, 0.0f, 10.0f, false, true);
	/*
	//Brazos
	//Box2DHelper::CreateDistanceJoint(phyWorld, Torso, Torso->GetWorldCenter() - b2Vec2(0, 5.0f), BrazoD, BrazoD->GetWorldCenter() - b2Vec2(0, 1.0f), 0.5f, 50.0f, 1.0f);
	Box2DHelper::CreateRevoluteJoint(phyWorld, Torso, Torso->GetWorldCenter() + b2Vec2(2,-5.0f), BrazoD, -0.5f * b2_pi, 0, 0.0f, 10.0f, false, true);
	//Box2DHelper::CreateDistanceJoint(phyWorld, Torso, Torso->GetWorldCenter() - b2Vec2(0, 5.0f), BrazoI, BrazoI->GetWorldCenter() - b2Vec2(0, 1.0f), 0.5f, 50.0f, 1.0f);
	Box2DHelper::CreateRevoluteJoint(phyWorld, Torso, Torso->GetWorldCenter() + b2Vec2(-2, -5.0f), BrazoI, 0, 0.5f * b2_pi, 0.0f, 10.0f, false, true);
	
	
	//Piernitas
	//Box2DHelper::CreateDistanceJoint(phyWorld, Torso, Torso->GetWorldCenter(), PiernaD, PiernaD->GetWorldCenter() - b2Vec2(0, 5.0f), 10.0f, 0.3f, 1.0f);
	Box2DHelper::CreateRevoluteJoint(phyWorld, Torso, Torso->GetWorldCenter()+b2Vec2(2,5), PiernaD, -0.25f * b2_pi, 0, 0.0f, 10.0f, false, true);
	//Box2DHelper::CreateDistanceJoint(phyWorld, Torso, Torso->GetWorldCenter(), PiernaI, PiernaI->GetWorldCenter() - b2Vec2(0, 5.0f), 10.0f, 0.3f, 1.0f);
	Box2DHelper::CreateRevoluteJoint(phyWorld, Torso, Torso->GetWorldCenter() + b2Vec2(-2, 5), PiernaI, 0, 0.25f * b2_pi, 0.0f, 10.0f, false, true);
	*/
	
}

Game::~Game(void)
{
	// Destructor de la clase Game (a implementar si es necesario)
}