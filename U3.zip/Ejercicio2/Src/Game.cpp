#include "Game.h"
#include "Box2DHelper.h"
#include <iostream>

Game::Game(int ancho, int alto, std::string titulo)
{
    wnd = new sf::RenderWindow(sf::VideoMode(ancho, alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;
    clearColor = sf::Color::Black;
    SetZoom();
    InitPhysics();

    

    // Inicialmente, no se est� arrastrando ning�n cuerpo
    draggedBody = nullptr;
}

Game::~Game()
{
    delete phyWorld;
    delete wnd;
}

void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor);
        DoEvents();

        // Si se est� arrastrando un cuerpo, se actualiza su velocidad para moverlo hacia la posici�n del mouse
        if (draggedBody)
        {
            sf::Vector2i pixelPos = sf::Mouse::getPosition(*wnd);
            sf::Vector2f worldPos = wnd->mapPixelToCoords(pixelPos, wnd->getView());
            b2Vec2 currentPos = draggedBody->GetPosition();
            b2Vec2 target(worldPos.x, worldPos.y);
            b2Vec2 diff = target - currentPos;
            // Factor de respuesta: ajustar seg�n convenga para mayor o menor velocidad
            float factor = 10.0f;
            draggedBody->SetLinearVelocity(factor * diff);
        }

        UpdatePhysics();
        DrawGame();
        wnd->display();
    }
}

void Game::UpdatePhysics()
{
    phyWorld->Step(1.0f / 60.0f, 8, 8);  // Simulaci�n a 120 FPS para f�sica
    phyWorld->ClearForces();
}

void Game::DrawGame()
{
    // Dibujar el suelo
    sf::RectangleShape groundShape(sf::Vector2f(100, 10));
    groundShape.setFillColor(sf::Color::Red);
    groundShape.setPosition(0, 95);
    wnd->draw(groundShape);

    // Dibujar las paredes
    sf::RectangleShape leftWallShape(sf::Vector2f(10, 100));
    leftWallShape.setFillColor(sf::Color::Red);
    leftWallShape.setPosition(-5, 0);
    wnd->draw(leftWallShape);

    sf::RectangleShape rightWallShape(sf::Vector2f(10, 100));
    rightWallShape.setFillColor(sf::Color::Red);
    rightWallShape.setPosition(95, 0);
    wnd->draw(rightWallShape);

    sf::RectangleShape topWallShape(sf::Vector2f(100, 10));
    topWallShape.setFillColor(sf::Color::Red);
    topWallShape.setPosition(0, -5);
    wnd->draw(topWallShape);

    controlBodyAvatar1->Actualizar();
    controlBodyAvatar1->Dibujar(*wnd);
    controlBodyAvatar2->Actualizar();
    controlBodyAvatar2->Dibujar(*wnd);
}

void Game::DoEvents()
{
    sf::Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case sf::Event::Closed:
            wnd->close();
            break;

        case sf::Event::MouseButtonPressed:
            if (evt.mouseButton.button == sf::Mouse::Left)
            {
                sf::Vector2f mousePos = wnd->mapPixelToCoords(sf::Vector2i(evt.mouseButton.x, evt.mouseButton.y), wnd->getView());
                std::cout << "MouseButtonPressed at: " << mousePos.x << ", " << mousePos.y << std::endl;
                mouseClick(mousePos);
            }
            break;

        case sf::Event::MouseButtonReleased:
            if (draggedBody)
            {
                std::cout << "MouseButtonReleased - releasing dragged body." << std::endl;
                // Al soltar, se detiene el arrastre y se anula el cuerpo arrastrado
                draggedBody->SetLinearVelocity(b2Vec2_zero);
                draggedBody = nullptr;
            }
            break;

        default:
            break;
        }
    }
}

void Game::mouseClick(sf::Vector2f mousePos)
{
    // Si ya hay un cuerpo arrastrado, no se hace nada
    if (draggedBody)
        return;

    std::cout << "mouseClick invoked at: " << mousePos.x << ", " << mousePos.y << std::endl;
    // Se verifica cu�l avatar fue clickeado
    if (controlBodyAvatar1->contienePosicion(mousePos))
    {
        std::cout << "Avatar 1 detected as clicked." << std::endl;
        draggedBody = controlBody;
    }
    else if (controlBodyAvatar2->contienePosicion(mousePos))
    {
        std::cout << "Avatar 2 detected as clicked." << std::endl;
        draggedBody = Body2;
    }
    else
    {
        std::cout << "No avatar was clicked." << std::endl;
    }
}

void Game::SetZoom()
{
    sf::View camara;
    camara.setSize(100.0f, 100.0f);
    camara.setCenter(50.0f, 50.0f);
    wnd->setView(camara);
}

void Game::InitPhysics()
{
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));
    debugRender = new SFMLRenderer(wnd);
    debugRender->SetFlags(UINT_MAX);
    phyWorld->SetDebugDraw(debugRender);

    // Crear piso y paredes
    b2Body* groundBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 100, 10);
    groundBody->SetTransform(b2Vec2(50.0f, 100.0f), 0.0f);

    b2Body* leftWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 10, 100);
    leftWallBody->SetTransform(b2Vec2(0.0f, 50.0f), 0.0f);

    b2Body* rightWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 10, 100);
    rightWallBody->SetTransform(b2Vec2(100.0f, 50.0f), 0.0f);

    b2Body* topWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 100, 10);
    topWallBody->SetTransform(b2Vec2(50.0f, 0.0f), 0.0f);

    // Crear cuerpos din�micos
    controlBody = Box2DHelper::CreateCircularDynamicBody(phyWorld, 2.0f, 1.0f, 0.3f, 0.3f);
    controlBody->SetTransform(b2Vec2(30.0f, 30.0f), 0.0f);

    Body2 = Box2DHelper::CreateCircularDynamicBody(phyWorld, 2.0f, 1.0f, 0.3f, 0.3f);
    Body2->SetTransform(b2Vec2(50.0f, 30.0f), 0.0f);

    texturaPelota.loadFromFile("Pelota.png");
    controlBodyAvatar1 = new Avatar(controlBody, new sf::Sprite(texturaPelota));
    controlBodyAvatar2 = new Avatar(Body2, new sf::Sprite(texturaPelota));

    // Configuraci�n del joint de distancia (resorte) entre los dos cuerpos din�micos
    jointDef.Initialize(controlBody, Body2, controlBody->GetPosition(), Body2->GetWorldCenter());
    jointDef.length = 0.05f;
    jointDef.stiffness = 10.0f;
    jointDef.damping = 0.1f;
    phyWorld->CreateJoint(&jointDef);

    // Para este m�todo de drag directo no se utiliza un mousejoint
}
