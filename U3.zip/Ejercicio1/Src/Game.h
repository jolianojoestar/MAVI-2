#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include "SFMLRenderer.h"
#include <list>
#include "Avatar.h"

// Incluir Box2D
#include <Box2D/Box2D.h>

using namespace sf;

class Game
{
private:
    // Propiedades de la ventana
    int alto;
    int ancho;
    RenderWindow* wnd;
    Color clearColor;

    // Objeto de Box2D
    b2World* phyWorld;
    SFMLRenderer* debugRender;

    // Tiempo de frame
    float frameTime;
    int fps;

    // Cuerpos de Box2D de la escena
    b2Body* groundBody;
    b2Body* leftWallBody;
    b2Body* rightWallBody;
    b2Body* topWallBody;
    b2Body* controlBody;
    b2Body* Body2;
    Avatar* controlBodyAvatar1;
    Avatar* controlBodyAvatar2;
    b2DistanceJointDef jointDef;  // Se usa para el joint entre los dos cuerpos din�micos

    // Para el arrastre directo (sin joints)
    b2Body* draggedBody; // cuerpo que se est� arrastrando (apunta a controlBody o Body2)

    sf::Texture texturaPelota;

public:
    // Constructores, destructores e inicializadores
    Game(int ancho, int alto, std::string titulo);
    ~Game();
    void InitPhysics();

    // Ciclo principal del juego
    void Loop();
    void DrawGame();
    void UpdatePhysics();
    void DoEvents();
    void mouseClick(sf::Vector2f mousePos);
    void SetZoom();
};